package services;

import dto.RandomUpdateListRequest;
import dto.SportClubDetailListResponse;
import entities.FootballClub;
import entities.SportsClub;
import utils.ApplicationUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class PremierLeagueService {
    public static PremierLeagueService instance;

    private PremierLeagueService() {
    }

    public static PremierLeagueService getInstance() {
        if (instance == null) {
            instance = new PremierLeagueService();
        }
        return instance;
    }

    public ArrayList<SportsClub> getSportsClub() {
        System.out.println(ApplicationUtil.getSportsClubArrayList());
        return ApplicationUtil.getSportsClubArrayList();
    }

    public SportsClub createSportClub(SportsClub club) {
        ArrayList<SportsClub> tempList = new ArrayList<>();
        tempList = ApplicationUtil.getSportsClubArrayList();
        tempList.add(club);
        ApplicationUtil.writeArrayListToFile(tempList);
        return club;
    }

    public FootballClub createFootballClub(FootballClub footballClub) {
        ArrayList<SportsClub> tempList = new ArrayList<>();
        tempList = ApplicationUtil.getSportsClubArrayList();
        FootballClub footballClub1 = new FootballClub();
        footballClub1 = footballClub;
        tempList.add(footballClub1);
        ApplicationUtil.writeArrayListToFile(tempList);
        return footballClub;
    }

    public static int getClubCount() {
        ApplicationUtil.readClubList();
        return ApplicationUtil.getSportsClubArrayList().size();
    }

    public boolean checkClubExists(Integer regNumber) {
        ApplicationUtil.readClubList();
        ArrayList<SportsClub> leagueClubRecords = ApplicationUtil.getSportsClubArrayList();
        for (SportsClub sportsClubRegNumber : leagueClubRecords) {
            if (sportsClubRegNumber.getRegNumber() == regNumber) {
                return true;
            }
        }
        return false;
    }

    public void addNewClub(SportsClub sportsClub) {
        ApplicationUtil.readClubList();
        ArrayList<SportsClub> updatedArrayList = ApplicationUtil.getSportsClubArrayList();
        updatedArrayList.add(sportsClub);

        ApplicationUtil.writeArrayListToFile(updatedArrayList);
    }

    public void addStatistic(Integer registrationNumber, FootballClub footballClub) {
        ApplicationUtil.readClubList();
        boolean isRegNoFound = false;
        ArrayList<SportsClub> leagueClubRecords = ApplicationUtil.getSportsClubArrayList();
        for (SportsClub club : leagueClubRecords) {

            if (registrationNumber == club.getRegNumber()) {

                System.out.println(club.getClass());
                isRegNoFound = true;
                if (club instanceof FootballClub) {
                    ((FootballClub) club).setCoachName(footballClub.getCoachName());
                    ((FootballClub) club).setTotalPointInOneSeason(footballClub.getTotalPointInOneSeason());
                    ((FootballClub) club).setMemberCount(footballClub.getMemberCount());
                    ((FootballClub) club).setTotalOfPlayedMatches(footballClub.getTotalOfPlayedMatches());
                    ((FootballClub) club).setCountOfWins(footballClub.getCountOfWins());
                    ((FootballClub) club).setCountOfDraws(footballClub.getCountOfDraws());
                    ((FootballClub) club).setCountOfLoss(footballClub.getCountOfLoss());
                    ((FootballClub) club).setCountOfGoalReceived(footballClub.getCountOfGoalReceived());
                    ((FootballClub) club).setCountOfGoalsScored(footballClub.getCountOfGoalsScored());
                    ((FootballClub) club).setCountOfGoalDeference(footballClub.getCountOfGoalDeference());
                }
                ApplicationUtil.writeArrayListToFile(leagueClubRecords);
            }
        }
        if (!isRegNoFound) {
            System.out.println(registrationNumber + " Not Found ..!");
        }
    }

    public void deleteMember(Integer regNumber) {
        ApplicationUtil.readClubList();
        SportsClub tempSportClub = null;
        boolean isFound = false;
        ArrayList<SportsClub> leagueClubRecords = ApplicationUtil.getSportsClubArrayList();
        for (SportsClub sportsClub : leagueClubRecords) {

            if (sportsClub.getRegNumber() == regNumber) {
                isFound = true;
                tempSportClub = sportsClub;
            }
        }
        if (isFound == false) {
            System.out.println("Invalid Registration Number.");
        }
        if (tempSportClub != null) {

            leagueClubRecords.remove(tempSportClub);

            ApplicationUtil.writeArrayListToFile(leagueClubRecords);
        }
    }

    public void deleteMember(String name) {
        ApplicationUtil.readClubList();
        ArrayList<SportsClub> leagueClubRecords = ApplicationUtil.getSportsClubArrayList();
        for (SportsClub sportsClub : leagueClubRecords) {

            if (sportsClub.getClubName().equals(name)) {
                leagueClubRecords.remove(sportsClub);

                ApplicationUtil.writeArrayListToFile(leagueClubRecords);

            } else {
                System.out.println("\t (!!!) Invalid Club name...");
            }

        }
    }

    public void displayStatisticOfSelectedClub(Integer regNumber) {
        ApplicationUtil.readClubList();
        ArrayList<SportsClub> leagueClubRecords = ApplicationUtil.getSportsClubArrayList();
        for (SportsClub clubStatistic :
                leagueClubRecords) {
            if (clubStatistic.getRegNumber() == regNumber) {
                ApplicationUtil.readClubList();
                String regNum = "Registration_Number";
                String clubName = "Club_Name";
                String win = "Wins";
                String draw = "Draws";
                String loss = "Losses";
                String point = "Points";
                String gaolDef = "Goal Deference";
                String matchDate = "Last Played Date";
                System.out.println("::::::::::::::::::::::::::::Statistic Of Club::::::::::::::::::::::::::::::::::::::::::");
                System.out.println("\n");
                System.out.println("+-------------------------------------------------------------------------------------+");
                System.out.printf("| %15s| %15s| %10s| %10s| %10s| %10s| %15s| %15s|\n", regNum, clubName, win, draw, loss, point, gaolDef, matchDate);
                System.out.println("+-------------------------------------------------------------------------------------+");
                System.out.printf("| %15s| %15s| %10s| %10s| %10s| %10s| %15s| %15s|\n", clubStatistic.getRegNumber(), clubStatistic.getClubName(),
                        ((FootballClub) clubStatistic).getCountOfWins(), ((FootballClub) clubStatistic).getCountOfDraws(),
                        ((FootballClub) clubStatistic).getCountOfLoss(), ((FootballClub) clubStatistic).getTotalPointInOneSeason(),
                        ((FootballClub) clubStatistic).getCountOfGoalDeference(), ((FootballClub) clubStatistic).getMatchDate());
            }
        }
    }

    static void bubbleSort(ArrayList<SportsClub> arr) {
        int n = arr.size();
        FootballClub temp = null;
        for (int i = 0; i < n; i++) {
            for (int j = 1; j < (n - i); j++) {
                if (((FootballClub) arr.get(j - 1)).getTotalPointInOneSeason() < ((FootballClub) arr.get(j)).getTotalPointInOneSeason()) {
                    //swap elements
                    temp = (FootballClub) arr.get(j - 1);
                    arr.set(j - 1, arr.get(j));
                    arr.set(j, temp);
                } else if (((FootballClub) arr.get(j - 1)).getTotalPointInOneSeason() == ((FootballClub) arr.get(j)).getTotalPointInOneSeason()) {
                    if (((FootballClub) arr.get(j - 1)).getCountOfGoalDeference() < ((FootballClub) arr.get(j)).getCountOfGoalDeference()) {
                        temp = (FootballClub) arr.get(j - 1);
                        arr.set(j - 1, arr.get(j));
                        arr.set(j, temp);
                    }
                }

            }
        }

    }

    public void sortPremierLeagueTable() {
        ApplicationUtil.readClubList();
        ArrayList<SportsClub> leagueClubRecords = ApplicationUtil.getSportsClubArrayList();
        bubbleSort(leagueClubRecords);
        System.out.println("=================================================================================================");
        System.out.println("**************** Sorted By Points ****************");
        String RegNumber = "Reg_Number";
        String ClubName = "Club Name";
        String totalOfPlayedMatches = "Played Matches";
        String countOfWins = "Wins";
        String countOfDraws = "Draws";
        String countOfFailures = "Losses";
        String totalPointInOneSeason = "Points";
        String countOfGoalsScored = "Scored Goals";
        String countOfGoalReceived = "Received Goals";
        String goalDeference = "Goal Deference";
        System.out.printf("| %10s| %10s| %10s| %10s| %10s| %10s| %10s| %10s| %10s| %10s\n", RegNumber, ClubName, totalOfPlayedMatches,
                countOfWins, countOfDraws, countOfFailures, totalPointInOneSeason, countOfGoalsScored, countOfGoalReceived,
                goalDeference);
        for (SportsClub club : leagueClubRecords) {
            System.out.printf("| %10s|  %10s|  %10s|  %10s|  %10s|  %10s|  %10s|  %10s|  %10s|  %10s\n", club.getRegNumber(), club.getClubName(),
                    ((FootballClub) club).getTotalOfPlayedMatches(), ((FootballClub) club).getCountOfWins(),
                    ((FootballClub) club).getCountOfDraws(), ((FootballClub) club).getCountOfLoss(), ((FootballClub) club).getTotalPointInOneSeason(), ((FootballClub) club).getCountOfGoalsScored(),
                    ((FootballClub) club).getCountOfGoalReceived(), ((FootballClub) club).getCountOfGoalDeference());
        }


    }

    public boolean checkRegNoExists(int regNo) {
        boolean isFound = false;
        ApplicationUtil.readClubList();
        ArrayList<SportsClub> leagueClubRecords = ApplicationUtil.getSportsClubArrayList();
        for (SportsClub club : leagueClubRecords) {
            if (club.getRegNumber() == regNo) {
                isFound = true;
            }
        }
        return isFound;
    }

    private void getGoalDeference(Integer regNo, double newScoreScored, double newScoreReceived) {
        ApplicationUtil.readClubList();
        ArrayList<SportsClub> leagueClubRecords = ApplicationUtil.getSportsClubArrayList();
        for (SportsClub club : leagueClubRecords) {
            if (club.getRegNumber() == regNo) {
                double scoreScored = ((FootballClub) club).getCountOfGoalsScored();
                double scoreReceived = ((FootballClub) club).getCountOfGoalReceived();
                double scoreDeference = (scoreScored - scoreReceived);

                ((FootballClub) club).setCountOfGoalsScored(scoreScored + newScoreScored);
                ((FootballClub) club).setCountOfGoalReceived(scoreReceived + newScoreReceived);
                ((FootballClub) club).setCountOfGoalDeference(scoreDeference + (newScoreScored - newScoreReceived));
            }
        }
        ApplicationUtil.writeArrayListToFile(leagueClubRecords);
    }

    private void updateWinsTableScoreTable(Integer regNo) {
        ApplicationUtil.readClubList();
        ArrayList<SportsClub> leagueClubRecords = ApplicationUtil.getSportsClubArrayList();
        for (SportsClub club : leagueClubRecords) {
            if (club.getRegNumber() == regNo) {
                double currentWins = ((FootballClub) club).getCountOfWins();
                double currentMatchesPlayed = ((FootballClub) club).getTotalOfPlayedMatches();
                double currentPoint = ((FootballClub) club).getTotalPointInOneSeason();

                ((FootballClub) club).setCountOfWins(currentWins + 1.0);
                ((FootballClub) club).setTotalOfPlayedMatches(currentMatchesPlayed + 1.0);
                ((FootballClub) club).setTotalPointInOneSeason(currentPoint + 3.0);

            }
        }
        ApplicationUtil.writeArrayListToFile(leagueClubRecords);
    }

    private void updateDrawTable(Integer regNumOne, Integer regNumberTwo) {
        ApplicationUtil.readClubList();
        ArrayList<SportsClub> leagueClubRecords = ApplicationUtil.getSportsClubArrayList();
        for (SportsClub club : leagueClubRecords) {
            if (club.getRegNumber() == regNumOne || club.getRegNumber() == regNumberTwo) {
                double currentDraw = ((FootballClub) club).getCountOfDraws();
                double currentMatchesPlayed = ((FootballClub) club).getTotalOfPlayedMatches();
                double currentPoint = ((FootballClub) club).getTotalPointInOneSeason();

                ((FootballClub) club).setCountOfDraws(currentDraw + 1.0);
                ((FootballClub) club).setTotalPointInOneSeason(currentPoint + 1.0);
                ((FootballClub) club).setTotalOfPlayedMatches(currentMatchesPlayed + 1.0);
            }
        }
        ApplicationUtil.writeArrayListToFile(leagueClubRecords);
    }

    private void updateLossesTable(Integer regNumber) {
        ApplicationUtil.readClubList();
        ArrayList<SportsClub> leagueClubRecords = ApplicationUtil.getSportsClubArrayList();
        for (SportsClub club : leagueClubRecords) {
            if (club.getRegNumber() == regNumber) {
                double lossesCount = ((FootballClub) club).getCountOfLoss();
                double currentMatchesPlayed = ((FootballClub) club).getTotalOfPlayedMatches();
                ((FootballClub) club).setCountOfLoss(lossesCount + 1.0);
                ((FootballClub) club).setTotalOfPlayedMatches(currentMatchesPlayed + 1.0);
            }
        }

        ApplicationUtil.writeArrayListToFile(leagueClubRecords);
    }

    private void updateDate(Integer regNumOne, Integer regNumberTwo, String matchDate) {
        ApplicationUtil.readClubList();
        ArrayList<SportsClub> leagueClubRecords = ApplicationUtil.getSportsClubArrayList();
        for (SportsClub club : leagueClubRecords) {
            if (club.getRegNumber() == regNumOne || club.getRegNumber() == regNumberTwo) {
                ((FootballClub) club).setMatchDate(matchDate);
            }
        }

        ApplicationUtil.writeArrayListToFile(leagueClubRecords);

    }


    public void updateStatistic(RandomUpdateListRequest randomUpdateListRequest) {

        Integer regNumberOne = randomUpdateListRequest.getRegNumOne();
        Integer regNumberTwo = randomUpdateListRequest.getRegNumTwo();
        double teamOneScore = randomUpdateListRequest.getTeamOneScore();
        double teamTwoScore = randomUpdateListRequest.getTeamTwoScore();
        double scoreOneReceived = randomUpdateListRequest.getTeamTwoScore();
        double scoreTwoReceived = randomUpdateListRequest.getTeamOneScore();
        //String matchDate = new SimpleDateFormat("dd/MM/yyyy").format(Calendar.getInstance().getTime());

        ApplicationUtil.readClubList();
        if (teamOneScore > teamTwoScore) {
            System.out.println("Team one wins");
            updateWinsTableScoreTable(regNumberOne);
            updateLossesTable(regNumberTwo);
            //updateDate(regNumberOne, regNumberTwo, matchDate);

            getGoalDeference(regNumberOne, teamOneScore, scoreOneReceived);
            getGoalDeference(regNumberTwo, teamTwoScore, scoreTwoReceived);
        } else if (teamOneScore < teamTwoScore) {
            System.out.println("Team two wins");
            updateWinsTableScoreTable(regNumberTwo);
            updateLossesTable(regNumberOne);
            //updateDate(regNumberOne, regNumberTwo, matchDate);

            System.out.println(teamOneScore + " " + scoreOneReceived + teamTwoScore + " " + scoreTwoReceived);
            getGoalDeference(regNumberOne, teamOneScore, scoreOneReceived);
            getGoalDeference(regNumberTwo, teamTwoScore, scoreTwoReceived);
        } else if (teamOneScore == teamTwoScore) {
            System.out.println("Draw");
            updateDrawTable(regNumberOne, regNumberTwo);
            //updateDate(regNumberOne, regNumberTwo, matchDate);
        }
    }

    public ArrayList<SportClubDetailListResponse> getSportsClubListDetails() {
        ApplicationUtil.readClubList();
        ArrayList<SportsClub> leagueClubRecords = ApplicationUtil.getSportsClubArrayList();
        ArrayList<SportClubDetailListResponse> sportClubDetailListResponseArrayList = new ArrayList<>();
        for (SportsClub club : leagueClubRecords) {
            SportClubDetailListResponse tempResponse = new SportClubDetailListResponse();
            tempResponse.setRegNum(club.getRegNumber());
            tempResponse.setClubName(club.getClubName());
            if (club instanceof FootballClub) {
                tempResponse.setWin(((FootballClub) club).getCountOfWins());
                tempResponse.setDraw(((FootballClub) club).getCountOfDraws());
                tempResponse.setLoss(((FootballClub) club).getCountOfLoss());
                tempResponse.setPoint(((FootballClub) club).getTotalPointInOneSeason());
                tempResponse.setGaolDef(((FootballClub) club).getCountOfGoalDeference());
                tempResponse.setMatchDate(((FootballClub) club).getMatchDate());
            }
            sportClubDetailListResponseArrayList.add(tempResponse);
        }
        return sportClubDetailListResponseArrayList;
    }
}
