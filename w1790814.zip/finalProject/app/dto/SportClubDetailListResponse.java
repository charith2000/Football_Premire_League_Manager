package dto;

public class SportClubDetailListResponse {
    private int regNum;
    private String clubName;
    private double win;
    private double draw;
    private double loss;
    private double point;
    private double gaolDef;
    private String matchDate;

    public SportClubDetailListResponse() {
    }

    public SportClubDetailListResponse(int regNum, String clubName, double win, double draw, double loss, double point, double gaolDef, String matchDate) {
        this.regNum = regNum;
        this.clubName = clubName;
        this.win = win;
        this.draw = draw;
        this.loss = loss;
        this.point = point;
        this.gaolDef = gaolDef;
        this.matchDate = matchDate;
    }

    public int getRegNum() {
        return regNum;
    }

    public void setRegNum(int regNum) {
        this.regNum = regNum;
    }

    public String getClubName() {
        return clubName;
    }

    public void setClubName(String clubName) {
        this.clubName = clubName;
    }

    public double getWin() {
        return win;
    }

    public void setWin(double win) {
        this.win = win;
    }

    public double getDraw() {
        return draw;
    }

    public void setDraw(double draw) {
        this.draw = draw;
    }

    public double getLoss() {
        return loss;
    }

    public void setLoss(double loss) {
        this.loss = loss;
    }

    public double getPoint() {
        return point;
    }

    public void setPoint(double point) {
        this.point = point;
    }

    public double getGaolDef() {
        return gaolDef;
    }

    public void setGaolDef(double gaolDef) {
        this.gaolDef = gaolDef;
    }

    public String getMatchDate() {
        return matchDate;
    }

    public void setMatchDate(String matchDate) {
        this.matchDate = matchDate;
    }

    @Override
    public String toString() {
        return "SportClubDetailListResponse{" +
                "regNum='" + regNum + '\'' +
                ", clubName='" + clubName + '\'' +
                ", win='" + win + '\'' +
                ", draw='" + draw + '\'' +
                ", loss='" + loss + '\'' +
                ", point='" + point + '\'' +
                ", gaolDef='" + gaolDef + '\'' +
                ", matchDate='" + matchDate + '\'' +
                '}';
    }
}

