package dto;

public class RandomUpdateListRequest {
    private int regNumOne;
    private int regNumTwo;
    private double teamOneScore;
    private double teamTwoScore;

    public RandomUpdateListRequest(){
    }

    public RandomUpdateListRequest(int regNumOne, int regNumTwo, double teamOneScore, double teamTwoScore) {
        this.regNumOne = regNumOne;
        this.regNumTwo = regNumTwo;
        this.teamOneScore = teamOneScore;
        this.teamTwoScore = teamTwoScore;
    }

    public int getRegNumOne() {
        return regNumOne;
    }

    public void setRegNumOne(int regNumOne) {
        this.regNumOne = regNumOne;
    }

    public int getRegNumTwo() {
        return regNumTwo;
    }

    public void setRegNumTwo(int regNumTwo) {
        this.regNumTwo = regNumTwo;
    }

    public double getTeamOneScore() {
        return teamOneScore;
    }

    public void setTeamOneScore(double teamOneScore) {
        this.teamOneScore = teamOneScore;
    }

    public double getTeamTwoScore() {
        return teamTwoScore;
    }

    public void setTeamTwoScore(double teamTwoScore) {
        this.teamTwoScore = teamTwoScore;
    }

    @Override
    public String toString() {
        return "RandomUpdateListResponse{" +
                "regNumOne=" + regNumOne +
                ", regNumTwo=" + regNumTwo +
                ", teamOneScore=" + teamOneScore +
                ", teamTwoScore=" + teamTwoScore +
                '}';
    }
}
