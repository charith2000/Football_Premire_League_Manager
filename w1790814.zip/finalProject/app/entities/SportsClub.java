package entities;

import java.io.Serializable;

public class SportsClub implements Serializable {
    private static final long serialVersionUID = 100;
    private String ClubName;
    private int regNumber;
    private int regYear;
    private String location;
    private String managerName;
    private String clubEmail;

    public SportsClub() {
    }

    public SportsClub(String clubName, int regNumber, int regYear, String location, String managerName, String clubEmail) {
        ClubName = clubName;
        this.regNumber = regNumber;
        this.regYear = regYear;
        this.location = location;
        this.managerName = managerName;
        this.clubEmail = clubEmail;
    }

    public String getClubName() {
        return ClubName;
    }

    public void setClubName(String clubName) {
        ClubName = clubName;
    }

    public int getRegNumber() {
        return regNumber;
    }

    public void setRegNumber(int regNumber) {
        this.regNumber = regNumber;
    }

    public int getRegYear() {
        return regYear;
    }

    public void setRegYear(int regYear) {
        this.regYear = regYear;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getManagerName() {
        return managerName;
    }

    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }

    public String getClubEmail() {
        return clubEmail;
    }

    public void setClubEmail(String clubEmail) {
        this.clubEmail = clubEmail;
    }

    @Override
    public String toString() {
        return "SportsClub{" +
                "ClubName='" + ClubName + '\'' +
                ", regNumber=" + regNumber +
                ", regYear=" + regYear +
                ", location='" + location + '\'' +
                ", managerName='" + managerName + '\'' +
                ", clubEmail='" + clubEmail + '\'' +
                '}';
    }
}
