package entities;

import java.io.Serializable;

public class FootballClub extends SportsClub implements Serializable {
    private static final long serialVersionUID = 100;
    private String coachName;
    private int memberCount;
    private double totalPointInOneSeason;
    private double totalOfPlayedMatches;
    private double countOfWins;
    private double countOfDraws;
    private double countOfLoss;
    private double countOfGoalReceived;
    private double countOfGoalsScored;
    private double CountOfGoalDeference;
    private String matchDate;

    public FootballClub(String clubName, int regNumber, int regYear, String location,
                        String managerName, String clubEmail, String coachName,
                        int memberCount, double totalPointInOneSeason,
                        double totalOfPlayedMatches, double countOfWins,
                        double countOfDraws, double countOfLoss,
                        double countOfGoalReceived, double countOfGoalsScored,
                        double countOfGoalDeference, String matchDate) {

        super(clubName, regNumber, regYear, location, managerName, clubEmail);
        this.coachName = coachName;
        this.memberCount = memberCount;
        this.totalPointInOneSeason = totalPointInOneSeason;
        this.totalOfPlayedMatches = totalOfPlayedMatches;
        this.countOfWins = countOfWins;
        this.countOfDraws = countOfDraws;
        this.countOfLoss = countOfLoss;
        this.countOfGoalReceived = countOfGoalReceived;
        this.countOfGoalsScored = countOfGoalsScored;
        CountOfGoalDeference = countOfGoalDeference;
        this.matchDate = matchDate;
    }

    public FootballClub() {
    }

    public String getMatchDate() {
        return matchDate;
    }

    public void setMatchDate(String matchDate) {
        this.matchDate = matchDate;
    }

    public String getCoachName() {
        return coachName;
    }

    public void setCoachName(String coachName) {
        this.coachName = coachName;
    }

    public int getMemberCount() {
        return memberCount;
    }

    public void setMemberCount(int memberCount) {
        this.memberCount = memberCount;
    }

    public double getTotalPointInOneSeason() {
        return totalPointInOneSeason;
    }

    public void setTotalPointInOneSeason(double totalPointInOneSeason) {
        this.totalPointInOneSeason = totalPointInOneSeason;
    }

    public double getTotalOfPlayedMatches() {
        return totalOfPlayedMatches;
    }

    public void setTotalOfPlayedMatches(double totalOfPlayedMatches) {
        this.totalOfPlayedMatches = totalOfPlayedMatches;
    }

    public double getCountOfWins() {
        return countOfWins;
    }

    public void setCountOfWins(double countOfWins) {
        this.countOfWins = countOfWins;
    }

    public double getCountOfDraws() {
        return countOfDraws;
    }

    public void setCountOfDraws(double countOfDraws) {
        this.countOfDraws = countOfDraws;
    }

    public double getCountOfLoss() {
        return countOfLoss;
    }

    public void setCountOfLoss(double countOfLoss) {
        this.countOfLoss = countOfLoss;
    }

    public double getCountOfGoalReceived() {
        return countOfGoalReceived;
    }

    public void setCountOfGoalReceived(double countOfGoalReceived) {
        this.countOfGoalReceived = countOfGoalReceived;
    }

    public double getCountOfGoalsScored() {
        return countOfGoalsScored;
    }

    public void setCountOfGoalsScored(double countOfGoalsScored) {
        this.countOfGoalsScored = countOfGoalsScored;
    }

    public double getCountOfGoalDeference() {
        return CountOfGoalDeference;
    }

    public void setCountOfGoalDeference(double countOfGoalDeference) {
        CountOfGoalDeference = countOfGoalDeference;
    }

}
