package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import dto.RandomUpdateListRequest;
import dto.SportClubDetailListResponse;
import entities.FootballClub;
import entities.SportsClub;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import services.PremierLeagueService;
import utils.ApplicationUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class PremierLeagueController extends Controller {

    public Result listSportsClub() {
        ArrayList<SportsClub> result = PremierLeagueService.getInstance().getSportsClub();
        System.out.println(result);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode jsonData = mapper.convertValue(result, JsonNode.class);
        return ok(ApplicationUtil.createResponse(jsonData, true));
    }

    public Result createSportsClub() {
        JsonNode json = request().body().asJson();
        if (json == null) {
            return badRequest(ApplicationUtil.createResponse("Expecting JSON data", false));
        }
        System.out.println(Json.fromJson(json, SportsClub.class));
        SportsClub result = PremierLeagueService.getInstance().createSportClub(Json.fromJson(json, SportsClub.class));
        JsonNode jsonObject = Json.toJson(result);
        return created(ApplicationUtil.createResponse(jsonObject, true));
    }

    public Result createFootballClub() {
        JsonNode json = request().body().asJson();
        if (json == null) {
            return badRequest(ApplicationUtil.createResponse("Expecting JSON data", false));
        }
        System.out.println(Json.fromJson(json, FootballClub.class));
        FootballClub result = PremierLeagueService.getInstance().createFootballClub(Json.fromJson(json, FootballClub.class));
        JsonNode jsonObject = Json.toJson(result);
        return created(ApplicationUtil.createResponse(jsonObject, true));
    }

    public Result getSportsClubDetailsList() {
        ArrayList<SportClubDetailListResponse> result = PremierLeagueService.getInstance().getSportsClubListDetails();
        System.out.println(result);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode jsonData = mapper.convertValue(result, JsonNode.class);
        return ok(ApplicationUtil.createResponse(jsonData, true));
    }

    public Result addStatistics(Integer registrationNumber) {
        JsonNode json = request().body().asJson();
        if (json == null) {
            return badRequest(ApplicationUtil.createResponse("Expecting JSON data", false));
        }
        PremierLeagueService.getInstance().addStatistic(registrationNumber, Json.fromJson(json, FootballClub.class));
        HashMap<String, String> response = new HashMap<>();
        response.put("message", "Reg No: " + registrationNumber + "Statistics updated successfully !");
        JsonNode jsonObject = Json.toJson(response);
        return created(ApplicationUtil.createResponse(jsonObject, true));
    }

    public Result updateStatistic() {
        JsonNode json = request().body().asJson();
        if (json == null) {
            return badRequest(ApplicationUtil.createResponse("Expecting JSON data", false));
        }
        PremierLeagueService.getInstance().updateStatistic(Json.fromJson(json, RandomUpdateListRequest.class));
        JsonNode jsonObject = Json.toJson(Json.fromJson(json, RandomUpdateListRequest.class));
        return ok(ApplicationUtil.createResponse(jsonObject, true));
    }
}
