package utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import entities.SportsClub;
import play.libs.Json;

import java.io.*;
import java.util.ArrayList;

public class ApplicationUtil {


    private static ArrayList<SportsClub> sportsClubArrayList = new ArrayList<>();

    public static ObjectNode createResponse(Object response, boolean ok) {
        ObjectNode result = Json.newObject();
        result.put("status", ok);
        if (response instanceof String)
            result.put("response", (String) response);
        else result.set("response", (JsonNode) response);

        return result;
    }

    public static ArrayList<SportsClub> getSportsClubArrayList() {
        readClubList();
        System.out.println("##############");
        for (SportsClub club : sportsClubArrayList) {
            System.out.println(club.getClass());
        }
        return sportsClubArrayList;
    }

    public static void readClubList() {
        System.out.println("Read Club List Method calls");
        FileInputStream saveFileStream = null;
        ObjectInputStream objectInputStream = null;
        File membersFile = new File("./data/premierLeagueManagerData.txt");
        if (membersFile.exists()) {
            try {
                saveFileStream = new FileInputStream("./data/premierLeagueManagerData.txt");
                while (saveFileStream.available() > 0) {
                    objectInputStream = new ObjectInputStream(saveFileStream);
                    sportsClubArrayList = (ArrayList<SportsClub>) objectInputStream.readObject();

                    System.out.println(sportsClubArrayList);
                }
                if (objectInputStream != null) {
                    objectInputStream.close();
                }
            } catch (ClassNotFoundException | IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void writeArrayListToFile(ArrayList<SportsClub> sportsClubsArrayList) {
        try {
            FileOutputStream fileOut =
                    new FileOutputStream("./data/premierLeagueManagerData.txt");
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
            objectOut.writeObject(sportsClubsArrayList);
            objectOut.close();
            fileOut.close();
            System.out.println("\n **** Club details added successfully ! ****");
            readClubList();
        } catch (IOException i) {
            i.printStackTrace();
        }
    }
}
