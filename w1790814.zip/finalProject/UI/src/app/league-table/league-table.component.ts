import {Component, OnInit, ViewChild} from '@angular/core';
import {Sort} from '@angular/material/sort';
import {RestService} from '../rest.service';
import {Data} from '../Data';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';

@Component({
  selector: 'app-league-table',
  templateUrl: './league-table.component.html',
  styleUrls: ['./league-table.component.css']
})
export class LeagueTableComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator | undefined;

  constructor(private rs: RestService) {
  }

  columns = ['Registration Number', 'Club Name', 'Wins', 'Draws', 'Losses', 'Points', 'Goal Difference', 'Match Date'];
  index = ['regNum', 'clubName', 'win', 'draw', 'loss', 'point', 'gaolDef', 'matchDate'] as const;

  data: Data[] = [];
  sortedData: Data[] = [];

  ngOnInit(): void {
    this.rs.getData().subscribe(
      (response) => {
        // @ts-ignore
        this.data = response.response;
        this.sortedData = this.data.slice();
        console.log(this.data);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  // tslint:disable-next-line:typedef
  sortData(sort: Sort) {
    const data = this.sortedData.slice();
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }

    this.sortedData = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'Registration Number':
          return compare(a.regNum, b.regNum, isAsc);
        case 'Club Name':
          return compare(a.clubName, b.clubName, isAsc);
        case 'Wins':
          return compare(a.win, b.win, isAsc);
        case 'Draws':
          return compare(a.draw, b.draw, isAsc);
        case 'Losses':
          return compare(a.loss, b.loss, isAsc);
        case 'Points':
          return compare(a.point, b.point, isAsc);
        case 'Goal Difference':
          return compare(a.gaolDef, b.gaolDef, isAsc);
        case 'Match Date':
          return compare(new Date(a.matchDate).getTime(), new Date(b.matchDate).getTime(), isAsc);
        default:
          return 0;
      }
    });
  }

  // // tslint:disable-next-line:typedef
  // applyFilter(event: Event) {
  //   const filterValue = (event.target as HTMLInputElement).value;
  //   // @ts-ignore
  //   this.sortedData.filter = filterValue.trim().toLowerCase();
  //
  // }

  onSearchChange(event: any): void {
    const searchValue = event.target.value;
    if (this.sortedData.filter(val => val.regNum.toString() === searchValue).length > 0) {
      this.sortedData = this.sortedData.filter(val => val.regNum.toString().includes(searchValue));
    }
    if (this.sortedData.filter(val => val.clubName.toLowerCase() === searchValue.toLowerCase()).length > 0) {
      this.sortedData = this.sortedData.filter(val => val.clubName.toLowerCase().includes(searchValue.toLowerCase()));
    }
    if (this.sortedData.filter(val => val.matchDate.toString() === searchValue).length > 0) {
      this.sortedData = this.sortedData.filter(val => val.matchDate.toString().includes(searchValue));
    }
    if (searchValue.length === 0) {
      this.sortedData = this.data;
    }
  }
}


// tslint:disable-next-line:typedef
function compare(a: string | number | Date, b: string | number | Date, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}


// @Component({
//   selector: 'app-league-table',
//   templateUrl: './league-table.component.html',
//   styleUrls: ['./league-table.component.css']
// })
// export class LeagueTableComponent implements OnInit {
//
//   elements: any = [];
//   columns = ['Registration Number', 'Club Name', 'Wins', 'Draws', 'Losses', 'Points', 'Goal Difference', 'Match Date'];
//   headElements = ['Registration Number', 'Club Name', 'Wins', 'Draws', 'Losses', 'Points', 'Goal Difference', 'Match Date'];
//   index = ['regNum', 'clubName', 'win', 'draw', 'loss', 'point', 'gaolDef', 'matchDate'] as const;
//   // tslint:disable-next-line:typedef
//   constructor(private rs: RestService) {
//   }
//   data: Data[] = [];
//   ngOnInit(): void {
//     for(){
//       this.rs.getData().subscribe(
//         (response) => {
//           // @ts-ignore
//           this.data = response.response;
//           console.log(this.data);
//         },
//         (error) => {
//           console.log(error);
//         }
//       );
//     }
//   }
// }



