import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HomeComponent} from './home/home.component';
import {LeagueTableComponent} from './league-table/league-table.component';
import {AutoGeneratorComponent} from './auto-generator/auto-generator.component';

const routes: Routes = [
  {path : 'home', component: HomeComponent},
  {path : 'leagueTable', component : LeagueTableComponent},
  {path : 'autoGenerator', component : AutoGeneratorComponent }
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
