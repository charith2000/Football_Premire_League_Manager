import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Data} from './Data';

@Injectable({
  providedIn: 'root'
})
export class UpdateDto {
  regNumOne: number | undefined;
  regNumTwo: number | undefined;
  teamOneScore: number | undefined;
  teamTwoScore: number | undefined;
}

export class RestService {

  constructor(private http: HttpClient) {
  }

  url = 'http://localhost:9000/api/clubDetailsList';
  updateUrl = 'http://localhost:9000/api/updateStatistic';

  // tslint:disable-next-line:typedef
  getData() {
    return this.http.get<Data[]>(this.url);
  }

  // tslint:disable-next-line:typedef
  updateStatistics(updateDto: UpdateDto) {
    return this.http.put(this.updateUrl, updateDto);
  }
}
