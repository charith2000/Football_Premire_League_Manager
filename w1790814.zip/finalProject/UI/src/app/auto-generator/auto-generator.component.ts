import {Component, OnInit} from '@angular/core';
import {RestService, UpdateDto} from '../rest.service';
import {Data} from '../Data';


@Component({
  selector: 'app-auto-generator',
  templateUrl: './auto-generator.component.html',
  styleUrls: ['./auto-generator.component.css']
})

export class AutoGeneratorComponent implements OnInit {
  constructor(private rs: RestService) {
  }

  data: Data[] = [];
  sortedData: Data[] = [];
  // @ts-ignore
  regNumOne: number;
  // @ts-ignore
  regNumTwo: number;
  // @ts-ignore
  scoreOne: number;
  // @ts-ignore
  scoreTwo: number;
 // @ts-ignore
  winningMsg: string;
  ngOnInit(): void {
    this.rs.getData().subscribe(
      (response) => {
        // @ts-ignore
        this.data = response.response;
        this.sortedData = this.data.slice();
        console.log(this.data);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  _autoGenerateNumber(min: number, max: number): number {
    const rand = Math.floor(Math.random() * (max - min + 1)) + min;
    return rand;
  }

  getRandomValues(): void {
    let clubOneIndex: number;
    let clubTwoIndex: number;
    do {
      clubOneIndex = this._autoGenerateNumber(0, (this.data.length - 1));
      clubTwoIndex = this._autoGenerateNumber(0, (this.data.length - 1));
    } while (clubOneIndex === clubTwoIndex);
    this.regNumOne = this.data[clubOneIndex].regNum;
    this.regNumTwo = this.data[clubTwoIndex].regNum;
    this.scoreOne = this._autoGenerateNumber(0, 10);
    this.scoreTwo = this._autoGenerateNumber(0, 10);

    const dto = new UpdateDto();
    dto.regNumOne = this.regNumOne;
    dto.regNumTwo = this.regNumTwo;
    dto.teamOneScore = this.scoreOne;
    dto.teamTwoScore = this.scoreTwo;
    if (this.scoreOne > this.scoreTwo) {
      this.winningMsg = 'Congratulation!!!! Team one Win !!!!';
    }else if (this.scoreOne === this.scoreTwo){
      this.winningMsg = 'Congratulation!!!! Match is Draw !!!!';
    }else {
      this.winningMsg = 'Congratulation!!!! Team two Win !!!!';
    }
    this.rs.updateStatistics(dto).subscribe((response) => {
      if (response) {
        console.log(response);
      }
    }, (error => {
      console.log(error);
    }));
  }
}
