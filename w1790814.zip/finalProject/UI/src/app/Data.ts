export interface Data {
  regNum: number;
  clubName: string;
  win: number;
  draw: number;
  loss: number;
  point: number;
  gaolDef: number;
  matchDate: string;
}

