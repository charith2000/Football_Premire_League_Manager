import java.io.Serializable;

public class DateValidator implements Serializable {
    private String membershipDate;

    public static boolean validateDate(String date) {
        Integer day, month, year;
        try {
            String dateParts[] = date.split("/");
            day = Integer.parseInt(dateParts[0]);
            month = Integer.parseInt(dateParts[1]);
            year = Integer.parseInt(dateParts[2]);

        } catch (Exception exception) {
            return false;
        }

        if (day >= 1 && day <= 31) {
            if (month >= 1 && month <= 12) {
                if ((int) (Math.log10(year) + 1) == 4) {
                    return true;
                } else {
                    System.out.println("Invalid Year. Please enter the year with four digits");
                }
            } else {
                System.out.println("Invalid Month");
            }
        } else {
            System.out.println("Invalid Date");
        }
        return false;
    }

    public String getMembershipDate() {
        return membershipDate;
    }

    public void setMembershipDate(String membershipDate) throws Exception {
        this.membershipDate = membershipDate;
    }
}
