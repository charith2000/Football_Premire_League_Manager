import entities.FootballClub;
import entities.SchoolFootballClub;
import entities.SportsClub;

import java.io.*;
import java.util.ArrayList;

public class PremierLeagueManager implements LeagueManager {
    private static ArrayList<SportsClub> LeagueClubRecords = new ArrayList<>();
    private static ArrayList<SportsClub> leagueClubRecordsByDate = new ArrayList<>();

    public static void readClubList() {
        FileInputStream saveFileStream = null;
        ObjectInputStream objectInputStream = null;
        File membersFile = new File("E:/oop 2nyear 1st sem/finalProject/data/premierLeagueManagerData.txt");
        if (membersFile.exists()) {
            try {
                saveFileStream = new FileInputStream("E:/oop 2nyear 1st sem/finalProject/data/premierLeagueManagerData.txt");
                while (saveFileStream.available() > 0) {
                    objectInputStream = new ObjectInputStream(saveFileStream);
                    ArrayList<SportsClub> memberListSaveFile = (ArrayList<SportsClub>) objectInputStream.readObject();
                    LeagueClubRecords = memberListSaveFile;

                }
                if (objectInputStream != null) {
                    objectInputStream.close();
                }
            } catch (ClassNotFoundException | IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void writeArrayListToFile(ArrayList<SportsClub> sportsClubsArrayList) {
        try {
            FileOutputStream fileOut =
                    new FileOutputStream("E:/oop 2nyear 1st sem/finalProject/data/premierLeagueManagerData.txt");
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
            objectOut.writeObject(sportsClubsArrayList);
            objectOut.close();
            fileOut.close();
            System.out.println("\n **** Club details added successfully ! ****");
            readClubList();

        } catch (IOException i) {
            i.printStackTrace();
        }
    }

    public static ArrayList<SportsClub> getLeagueClubRecords() {
        readClubList();
        return LeagueClubRecords;
    }

    public static int getClubCount() {
        readClubList();
        return LeagueClubRecords.size();
    }

    @Override
    public boolean checkClubExists(Integer regNumber) {
        readClubList();
        for (SportsClub sportsClubRegNumber : LeagueClubRecords) {
            if (sportsClubRegNumber.getRegNumber() == regNumber) {
                return true;
            }

        }
        return false;
    }

    @Override
    public void addNewClub(SportsClub sportsClub) {
        readClubList();
        LeagueClubRecords.add(sportsClub);

        writeArrayListToFile(LeagueClubRecords);
    }

    @Override
    public void addStatistic(Integer registrationNumber, FootballClub footballClub) {
        readClubList();
        Boolean isRegNoFound = false;
        for (SportsClub club : LeagueClubRecords) {
            if (club.getRegNumber() == registrationNumber) {
                isRegNoFound = true;
                ((FootballClub) club).setCoachName(footballClub.getCoachName());
                ((FootballClub) club).setTotalPointInOneSeason(footballClub.getTotalPointInOneSeason());
                ((FootballClub) club).setMemberCount(footballClub.getMemberCount());
                ((FootballClub) club).setTotalOfPlayedMatches(footballClub.getTotalOfPlayedMatches());
                ((FootballClub) club).setCountOfWins(footballClub.getCountOfWins());
                ((FootballClub) club).setCountOfDraws(footballClub.getCountOfDraws());
                ((FootballClub) club).setCountOfLoss(footballClub.getCountOfLoss());
                ((FootballClub) club).setCountOfGoalReceived(footballClub.getCountOfGoalReceived());
                ((FootballClub) club).setCountOfGoalsScored(footballClub.getCountOfGoalsScored());
                ((FootballClub) club).setCountOfGoalDeference(footballClub.getCountOfGoalDeference());

                writeArrayListToFile(LeagueClubRecords);
            }
        }
        if (!isRegNoFound) {
            System.out.println(registrationNumber + " Not Found ..!");
        }
    }

    @Override
    public void deleteMember(Integer regNumber) {
        readClubList();
        SportsClub tempSportClub = null;
        boolean isFound = false;
        for (SportsClub sportsClub : LeagueClubRecords) {

            if (sportsClub.getRegNumber() == regNumber) {
                isFound = true;
                tempSportClub = sportsClub;
            }
        }
        if (isFound == false) {
            System.out.println("Invalid Registration Number.");
        }
        if (tempSportClub != null) {
            LeagueClubRecords.remove(tempSportClub);

            writeArrayListToFile(LeagueClubRecords);
        }
    }

    @Override
    public void deleteMember(String name) {
        readClubList();
        for (SportsClub sportsClub : LeagueClubRecords) {

            if (sportsClub.getClubName().equals(name)) {
                LeagueClubRecords.remove(sportsClub);

                writeArrayListToFile(LeagueClubRecords);

            } else {
                System.out.println("\t (!!!) Invalid Club name...");
            }

        }
    }

    @Override
    public void displayStatisticOfSelectedClub(Integer regNumber) {
        readClubList();
        for (SportsClub clubStatistic :
                LeagueClubRecords) {
            if (clubStatistic.getRegNumber() == regNumber) {
                readClubList();
                String regNum = "Registration_Number";
                String clubName = "Club_Name";
                String win = "Wins";
                String draw = "Draws";
                String loss = "Losses";
                String point = "Points";
                String gaolDef = "Goal Deference";
                String matchDate = "Last Played Date";
                System.out.println("::::::::::::::::::::::::::::Statistic Of Club::::::::::::::::::::::::::::::::::::::::::");
                System.out.println("\n");
                System.out.println("+-------------------------------------------------------------------------------------+");
                System.out.printf("| %15s| %15s| %10s| %10s| %10s| %10s| %15s| %15s|\n", regNum, clubName, win, draw, loss, point, gaolDef, matchDate);
                System.out.println("+-------------------------------------------------------------------------------------+");
                System.out.printf("| %15s| %15s| %10s| %10s| %10s| %10s| %15s| %15s|\n", clubStatistic.getRegNumber(), clubStatistic.getClubName(),
                        ((FootballClub) clubStatistic).getCountOfWins(), ((FootballClub) clubStatistic).getCountOfDraws(),
                        ((FootballClub) clubStatistic).getCountOfLoss(), ((FootballClub) clubStatistic).getTotalPointInOneSeason(),
                        ((FootballClub) clubStatistic).getCountOfGoalDeference(), ((FootballClub) clubStatistic).getMatchDate());
            }
        }
    }

    static void bubbleSort(ArrayList<SportsClub> arr) {
        int n = arr.size();
        FootballClub temp = null;
        for (int i = 0; i < n; i++) {
            for (int j = 1; j < (n - i); j++) {
                if (((FootballClub) arr.get(j - 1)).getTotalPointInOneSeason() < ((FootballClub) arr.get(j)).getTotalPointInOneSeason()) {
                    //swap elements
                    temp = (FootballClub) arr.get(j - 1);
                    arr.set(j - 1, arr.get(j));
                    arr.set(j, temp);
                } else if (((FootballClub) arr.get(j - 1)).getTotalPointInOneSeason() == ((FootballClub) arr.get(j)).getTotalPointInOneSeason()) {
                    if (((FootballClub) arr.get(j - 1)).getCountOfGoalDeference() < ((FootballClub) arr.get(j)).getCountOfGoalDeference()) {
                        temp = (FootballClub) arr.get(j - 1);
                        arr.set(j - 1, arr.get(j));
                        arr.set(j, temp);
                    }
                }

            }
        }

    }

    @Override
    public void sortPremierLeagueTable() {
        readClubList();
        bubbleSort(LeagueClubRecords);
        System.out.println("=================================================================================================");
        System.out.println("**************** Sorted By Points ****************");
        String RegNumber = "Reg_Number";
        String ClubName = "Club Name";
        String totalOfPlayedMatches = "Played Matches";
        String countOfWins = "Wings";
        String countOfDraws = "Draws";
        String countOfFailures = "Losses";
        String totalPointInOneSeason = "Points";
        String countOfGoalsScored = "Scored Goals";
        String countOfGoalReceived = "Received Goals";
        String goalDeference = "Goal Deference";
        System.out.printf("| %10s| %10s| %10s| %10s| %10s| %10s| %10s| %10s| %10s| %10s\n", RegNumber, ClubName, totalOfPlayedMatches,
                countOfWins, countOfDraws, countOfFailures, totalPointInOneSeason, countOfGoalsScored, countOfGoalReceived,
                goalDeference);
        for (SportsClub club : LeagueClubRecords) {
            System.out.println(club.getClass());
            System.out.printf("| %10s|  %10s|  %10s|  %10s|  %10s|  %10s|  %10s|  %10s|  %10s|  %10s\n", club.getRegNumber(), club.getClubName(),
                    ((FootballClub) club).getTotalOfPlayedMatches(), ((FootballClub) club).getCountOfWins(),
                    ((FootballClub) club).getCountOfDraws(), ((FootballClub) club).getCountOfLoss(), ((FootballClub) club).getTotalPointInOneSeason(), ((FootballClub) club).getCountOfGoalsScored(),
                    ((FootballClub) club).getCountOfGoalReceived(), ((FootballClub) club).getCountOfGoalDeference());
        }


    }

    public boolean checkRegNoExists(int regNo) {
        boolean isFound = false;
        readClubList();
        for (SportsClub club : LeagueClubRecords) {
            if (club.getRegNumber() == regNo) {
                isFound = true;
            }
        }
        return isFound;
    }

    private void getGoalDeference(Integer regNo, double newScoreScored, double newScoreReceived) {
        readClubList();
        for (SportsClub club : LeagueClubRecords) {
            if (club.getRegNumber() == regNo) {
                double scoreScored = ((FootballClub) club).getCountOfGoalsScored();
                double scoreReceived = ((FootballClub) club).getCountOfGoalReceived();
                double scoreDeference = (scoreScored - scoreReceived);

                ((FootballClub) club).setCountOfGoalsScored(scoreScored + newScoreScored);
                ((FootballClub) club).setCountOfGoalReceived(scoreReceived + newScoreReceived);
                ((FootballClub) club).setCountOfGoalDeference(scoreDeference + (newScoreScored - newScoreReceived));
            }
        }

        writeArrayListToFile(LeagueClubRecords);
    }

    private void updateWinsTableScoreTable(Integer regNo) {
        readClubList();
        for (SportsClub club : LeagueClubRecords) {
            if (club.getRegNumber() == regNo) {
                double currentWins = ((FootballClub) club).getCountOfWins();
                double currentMatchesPlayed = ((FootballClub) club).getTotalOfPlayedMatches();
                double currentPoint = ((FootballClub) club).getTotalPointInOneSeason();

                ((FootballClub) club).setCountOfWins(currentWins + 1.0);
                ((FootballClub) club).setTotalOfPlayedMatches(currentMatchesPlayed + 1.0);
                ((FootballClub) club).setTotalPointInOneSeason(currentPoint + 3.0);

            }
        }

        writeArrayListToFile(LeagueClubRecords);
    }

    private void updateDrawTable(Integer regNumOne, Integer regNumberTwo) {
        readClubList();
        for (SportsClub club : LeagueClubRecords) {
            if (club.getRegNumber() == regNumOne || club.getRegNumber() == regNumberTwo) {
                double currentDraw = ((FootballClub) club).getCountOfDraws();
                double currentMatchesPlayed = ((FootballClub) club).getTotalOfPlayedMatches();
                double currentPoint = ((FootballClub) club).getTotalPointInOneSeason();

                ((FootballClub) club).setCountOfDraws(currentDraw + 1.0);
                ((FootballClub) club).setTotalPointInOneSeason(currentPoint + 1.0);
                ((FootballClub) club).setTotalOfPlayedMatches(currentMatchesPlayed + 1.0);
            }
        }

        writeArrayListToFile(LeagueClubRecords);
    }

    private void updateLossesTable(Integer regNumber) {
        readClubList();
        for (SportsClub club : LeagueClubRecords) {
            if (club.getRegNumber() == regNumber) {
                double lossesCount = ((FootballClub) club).getCountOfLoss();
                double currentMatchesPlayed = ((FootballClub) club).getTotalOfPlayedMatches();
                ((FootballClub) club).setCountOfLoss(lossesCount + 1.0);
                ((FootballClub) club).setTotalOfPlayedMatches(currentMatchesPlayed + 1.0);
            }
        }

        writeArrayListToFile(LeagueClubRecords);
    }

    private void updateDate(Integer regNumOne, Integer regNumberTwo, String matchDate) {
        readClubList();
        for (SportsClub club : LeagueClubRecords) {
            if (club.getRegNumber() == regNumOne || club.getRegNumber() == regNumberTwo) {
                ((FootballClub) club).setMatchDate(matchDate);
            }
        }

        writeArrayListToFile(LeagueClubRecords);

    }

    @Override
    public void updateStatistic(Integer regNumberOne, Integer regNumberTwo, double teamOneScore, double teamTwoScore, double scoreOneReceived, double scoreTwoReceived, String matchDate) {
        readClubList();
        if (teamOneScore > teamTwoScore) {
            System.out.println("Team one wins");
            updateWinsTableScoreTable(regNumberOne);
            updateLossesTable(regNumberTwo);
            updateDate(regNumberOne, regNumberTwo, matchDate);

            getGoalDeference(regNumberOne, teamOneScore, scoreOneReceived);
            getGoalDeference(regNumberTwo, teamTwoScore, scoreTwoReceived);
        } else if (teamOneScore < teamTwoScore) {
            System.out.println("Team two wins");
            updateWinsTableScoreTable(regNumberTwo);
            updateLossesTable(regNumberOne);
            updateDate(regNumberOne, regNumberTwo, matchDate);

            System.out.println(teamOneScore + " " + scoreOneReceived + teamTwoScore + " " + scoreTwoReceived);
            getGoalDeference(regNumberOne, teamOneScore, scoreOneReceived);
            getGoalDeference(regNumberTwo, teamTwoScore, scoreTwoReceived);
        } else if (teamOneScore == teamTwoScore) {
            System.out.println("Draw");
            updateDrawTable(regNumberOne, regNumberTwo);
            updateDate(regNumberOne, regNumberTwo, matchDate);
        }
    }
}

