package entities;

import java.io.Serializable;

public class SchoolFootballClub extends FootballClub implements Serializable {
    private static final long serialVersionUID = 100;
    private String schoolName;

    public SchoolFootballClub(String clubName, int regNumber, int regYear,
                              String location, String managerName,
                              String clubEmail, String coachName, int memberCount,
                              double totalPointInOneSeason, double totalOfPlayedMatches,
                              double countOfWins, double countOfDraws, double countOfLoss,
                              double countOfGoalReceived, double countOfGoalsScored,
                              double countOfGoalDeference, String matchDate, String playedDate,
                              String schoolName) {
        super(clubName, regNumber, regYear, location, managerName, clubEmail, coachName,
                memberCount, totalPointInOneSeason, totalOfPlayedMatches, countOfWins,
                countOfDraws, countOfLoss, countOfGoalReceived, countOfGoalsScored, countOfGoalDeference,
                matchDate, playedDate);
        this.schoolName = schoolName;
    }

    public SchoolFootballClub(){

    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }
}
