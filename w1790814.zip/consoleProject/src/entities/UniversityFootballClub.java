package entities;

import java.io.Serializable;

public class UniversityFootballClub extends FootballClub implements Serializable {
    private static final long serialVersionUID = 100;
    private String universityName;
    private String universityClubYear;

    public UniversityFootballClub(String clubName, int regNumber, int regYear,
                                  String location, String managerName,
                                  String clubEmail, String coachName, int memberCount,
                                  double totalPointInOneSeason, double totalOfPlayedMatches,
                                  double countOfWins, double countOfDraws, double countOfLoss,
                                  double countOfGoalReceived, double countOfGoalsScored, double countOfGoalDeference,
                                  String matchDate, String playedDate, String universityName, String universityClubYear) {
        super(clubName, regNumber, regYear, location, managerName, clubEmail, coachName, memberCount,
                totalPointInOneSeason, totalOfPlayedMatches, countOfWins, countOfDraws, countOfLoss,
                countOfGoalReceived, countOfGoalsScored, countOfGoalDeference, matchDate, playedDate);
        this.universityName = universityName;
        this.universityClubYear = universityClubYear;
    }

    public UniversityFootballClub() {
    }

    public UniversityFootballClub(int regNumber, String clubName) {
    }


    public String getUniversityName() {
        return universityName;
    }

    public void setUniversityName(String universityName) {
        this.universityName = universityName;
    }

    public String getUniversityClubYear() {
        return universityClubYear;
    }

    public void setUniversityClubYear(String universityClubYear) {
        this.universityClubYear = universityClubYear;
    }

}
