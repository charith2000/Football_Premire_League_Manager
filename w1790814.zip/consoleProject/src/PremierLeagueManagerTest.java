//import org.junit.jupiter.api.Test;

//import static org.junit.jupiter.api.Assertions.*;

//class PremierLeagueManagerTest {
/*
    @Test
    void checkRegNoExists() {
        assertTrue(new PremierLeagueManager().checkClubExists(1001));
        assertFalse(new PremierLeagueManager().checkClubExists(132242));
    }


    @Test
    void getClubCount() {
        assertTrue(PremierLeagueManager.getClubCount() > 0);
    }
	*/
//}