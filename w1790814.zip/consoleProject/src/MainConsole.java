import entities.FootballClub;
import entities.SchoolFootballClub;
import entities.UniversityFootballClub;
import javafx.application.Application;

import java.awt.*;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Scanner;

public class MainConsole {
    private static Scanner consoleInput = new Scanner(System.in);
    private static PremierLeagueManager premierLeagueManager = new PremierLeagueManager();
    private static ConsoleInputManager consoleValidation = new ConsoleInputManager();
    private static UniversityFootballClub universityFootballClub = new UniversityFootballClub();
    private static SchoolFootballClub schoolFootballClub = new SchoolFootballClub();
    private static FootballClub footballClub = new FootballClub();


    public static void main(String[] args) {

        String isNeedToContinue = "y";
        while ("y".contentEquals(isNeedToContinue.toLowerCase())) {
            displayMainConsole();
            int choice = 0;
            choice = consoleValidation.getIntegerInput("\t * Enter your selection           :",
                    "\t ** Invalid Input...\n" +
                            "\t (!!!)Please re Enter your choice :");
            if (choice == 1 || choice == 2 || choice == 3 || choice == 4 || choice == 5 || choice == 6 || choice == 7) {
                if (choice == 1) {
                    addNewClub();
                } else if (choice == 2) {
                    addStatistics();
                } else if (choice == 3) {
                    displaySelectedClubStatistics();
                } else if (choice == 4) {
                    displayPremierLeagueTable();
                } else if (choice == 5) {
                    deleteClub();
                } else if (choice == 6) {
                    updateCurrentStatistics();
                } else if (choice == 7) {
                    openGui();
                }
                System.out.print("\t * Do you want to continue [y / n]: ");
                isNeedToContinue = consoleInput.next();
            } else {
                System.out.println("\\t ** Invalid Input...\\n\" +\n" +
                        "                            \"\\t (!!!)Please re Enter             :");
            }
        }
    }

    private static void openGui() {
        try{
            Desktop.getDesktop().browse(new URL("http://localhost:4200").toURI());
        }catch (IOException e){
            e.printStackTrace();
        }catch (URISyntaxException e){
            e.printStackTrace();
        }
    }

    private static void displayMainConsole() {
        System.out.println(":::::::::::::::: Premier League Manager ::::::::::::::::");
        System.out.println("\n");
        System.out.println("\t Select an option given bellow.");
        System.out.println("\t\t (1) Add new Football club.");
        System.out.println("\t\t (2) Add statistics to the club.");
        System.out.println("\t\t (3) Display statistics of selected club in Premier League.");
        System.out.println("\t\t (4) Display Premier League Table.");
        System.out.println("\t\t (5) Delete club.");
        System.out.println("\t\t (6) Update statistics.");
        System.out.println("\t\t (7) Open Graphical user interface.");
        System.out.println("::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
    }

    private static void addNewClub() {
        System.out.println(":::::::::::::::: Premier League Manager ::::::::::::::::");
        System.out.println(":::::::::::::::::::Add:::::New:::Club:::::::::::::::::::");
        System.out.println("\n");
        int clubCount = PremierLeagueManager.getClubCount();
        if (clubCount > 20) {
            System.out.println("(!!!!) Reached Maximum number of Football Clubs.....");
        } else {
            System.out.println("+------------------------------+");
            System.out.println("| Total of registered Clubs : " + clubCount);
            System.out.println("| Remaining Count           : " + (20 - clubCount));
            System.out.println("+------------------------------+");
            System.out.println("\n");

            int regNumber = 0;
            int regYear = 0;
            String type = null;
            regNumber = consoleValidation.getIntegerInput("\t (*) Enter club registration Number     :",
                    "(!!) Invalid Input...\n" +
                            "\t Please enter only integers             :");

            while (premierLeagueManager.checkClubExists(regNumber)) {
                System.out.println("\t (!!!) Register Number Exists. Please enter a new registration number...");
                regNumber = consoleValidation.getIntegerInput("\t (*) Enter club registration Number     :",
                        "(!!) Invalid Input...\n\t Please enter only integers             :");
            }
            System.out.print("\t (*) Enter Club registered name         :");
            String name = consoleInput.next();
            regYear = consoleValidation.getIntegerInput("\t (*) Enter club registered year         :",
                    "(!!) Invalid Input...\n" +
                            "\t Please enter only integers             :");
            System.out.print("\t (*) Enter club email                  :");
            String email = consoleInput.next();
            System.out.print("\t (*) Enter club location(city)         :");
            String location = consoleInput.next();
            System.out.println("\t (**) Select your club Type...");
            System.out.println("\t\t (A) University Football club.");
            System.out.println("\t\t (B) School Football club.");
            while (true) {
                type = consoleValidation.getAlphabetic("\t (*) Enter correct letter               :",
                        "(!!) Invalid Input...\n" +
                                "\t Please enter letter inside the bracket :");
                if ("A".equals(type.toUpperCase())) {

                    System.out.print("\t (*) Enter your university name        :");
                    String uniName = consoleInput.next();
                    System.out.print("\t (*) Enter your university year        :");
                    String uniYear = consoleInput.next();


                    universityFootballClub.setClubName(name);
                    universityFootballClub.setRegNumber(regNumber);
                    universityFootballClub.setRegYear(regYear);
                    universityFootballClub.setClubEmail(email);
                    universityFootballClub.setLocation(location);
                    universityFootballClub.setUniversityName(uniName);
                    universityFootballClub.setUniversityClubYear(uniYear);
                    premierLeagueManager.addNewClub(universityFootballClub);
                    System.out.println(universityFootballClub);
                    break;
                } else if ("B".equals(type.toUpperCase())) {

                    System.out.print("\t (*) Enter your school name             :");
                    String sclName = consoleInput.next();
                    schoolFootballClub.setClubName(name);
                    schoolFootballClub.setRegNumber(regNumber);
                    schoolFootballClub.setRegYear(regYear);
                    schoolFootballClub.setClubEmail(email);
                    schoolFootballClub.setLocation(location);
                    schoolFootballClub.setSchoolName(sclName);
                    premierLeagueManager.addNewClub(schoolFootballClub);
                    break;
                } else {
                    System.out.println("(!!!) Invalid Input Please re enter...");
                }
            }
        }
    }

    private static void addStatistics() {
        System.out.println(":::::::::::::::: Premier League Manager ::::::::::::::::");
        System.out.println("::::::::::::::::::::Add:::Statistic:::::::::::::::::::::");
        int regNumber = 0;
        regNumber = consoleValidation.getIntegerInput("\t (*) Enter club registration Number     :",
                "(!!) Invalid Input...\n" +
                        "\t Please enter only integers             :");
        String coachName = null;
        int memberCount = 0;
        double points = 0;
        double totalPlayedMatches = 0;
        double wins = 0;
        double draws = 0;
        double losses = 0;
        double receivedGoals = 0;
        double scoredGoals = 0;
        double goalDeference = 0;

        coachName = consoleValidation.getAlphabetic("\t (*) Enter club coach name              :",
                "(!!) Invalid Input...\n\t Please enter only strings              :");
        memberCount = consoleValidation.getIntegerInput("\t (*) Enter count of members             :",
                "(!!) Invalid Input...\n\t Please enter only integers             :");
        points = consoleValidation.getIntegerInput("\t (*) Enter total of current Points      :",
                "(!!) Invalid Input...\n\t Please enter only integers             :");
        while (true) {
            totalPlayedMatches = consoleValidation.getIntegerInput("\t (*) Enter total of played matches      :",
                    "(!!) Invalid Input...\n\t Please enter only integers             :");
            wins = consoleValidation.getIntegerInput("\t (*) Enter total of wins                :",
                    "(!!) Invalid Input...\n\t Please enter only integers             :");
            draws = consoleValidation.getIntegerInput("\t (*) Enter total of draws               :",
                    "(!!) Invalid Input...\n\t Please enter only integers             :");
            losses = consoleValidation.getIntegerInput("\t (*) Enter total of losses              :",
                    "(!!) Invalid Input...\n\t Please enter only integers             :");
            if (totalPlayedMatches == (wins + draws + losses)) {
                break;
            } else {
                System.out.println("(!!!) Invalid Input (!!!)");
                System.out.println("(!!!) Your total matches should be same to \n" +
                        "the count of wins, draws and losses.... ");

            }

        }
        receivedGoals = consoleValidation.getIntegerInput("\t (*) Enter received goals               :",
                "(!!) Invalid Input...\n\t Please enter only integers             :");
        scoredGoals = consoleValidation.getIntegerInput("\t (*) Enter scored goals                 :",
                "(!!) Invalid Input...\n\t Please enter only integers             :");
        goalDeference = (scoredGoals - receivedGoals);
        footballClub.setCoachName(coachName);
        footballClub.setTotalPointInOneSeason(points);
        footballClub.setMemberCount(memberCount);
        footballClub.setTotalOfPlayedMatches(totalPlayedMatches);
        footballClub.setCountOfWins(wins);
        footballClub.setCountOfDraws(draws);
        footballClub.setCountOfLoss(losses);
        footballClub.setCountOfGoalReceived(receivedGoals);
        footballClub.setCountOfGoalsScored(scoredGoals);
        footballClub.setCountOfGoalDeference(goalDeference);
        premierLeagueManager.addStatistic(regNumber, footballClub);
    }

    private static void displaySelectedClubStatistics() {
        System.out.println(":::::::::::::::: Premier League Manager ::::::::::::::::");
        System.out.println("::::::::::::::::::Display:::Statistic:::::::::::::::::::");
        int regNumber = 0;
        regNumber = consoleValidation.getIntegerInput("\t (*) Enter club registration Number     :",
                "(!!) Invalid Input...\n" +
                        "\t Please enter only integers             :");
        premierLeagueManager.displayStatisticOfSelectedClub(regNumber);

    }

    private static void displayPremierLeagueTable() {
        premierLeagueManager.sortPremierLeagueTable();
    }

    private static void deleteClub() {
        System.out.println("**************** Delete Club ****************");
        System.out.println("\t (!!!) Select method to delete club form this premiere league. (!!!)");
        System.out.println("\t (A) Delete by club name.");
        System.out.println("\t (B) Delete by Club Registration Number.");
        String type = null;
        type = consoleValidation.getAlphabetic("\t (*) Enter the type you want :", "\t (!!) Invalid Input !!" +
                "Please Enter Valid Letter :");

        while (true) {
            if ("A".equals(type.toUpperCase())) {
                System.out.print("\t (*) Enter your club name :");
                String name = consoleInput.next();
                premierLeagueManager.deleteMember(name);
                break;
            } else if ("B".equals(type.toUpperCase())) {
                int regNumber = 0;
                regNumber = consoleValidation.getIntegerInput("\t (*) Enter your club registration number :",
                        "\t (!!) Invalid Input... Please enter only integers :");
                premierLeagueManager.deleteMember(regNumber);
                break;
            }
        }

    }

    private static void updateCurrentStatistics() {
        System.out.println(":::::::::::::::: Premier League Manager ::::::::::::::::");
        System.out.println(":::::::::::::::::: Update:::Statistic:::::::::::::::::::");
        int teamOneRegNumber = 0;
        int teamTwoRegNumber = 0;
        double teamOneScore = 0;
        double teamTwoScore = 0;
        String matchDate = null;
        String playedDate = null;

        do {
            teamOneRegNumber = consoleValidation.getIntegerInput(
                    "\t (*) Enter 1 st club registration Number     :",
                    "(!!) Invalid Input...\n\t Please enter only integers             :"
            );
        } while (!premierLeagueManager.checkClubExists(teamOneRegNumber));
        do {
            teamTwoRegNumber = consoleValidation.getIntegerInput(
                    "\t (*) Enter 2 nd club registration Number     :",
                    "(!!) Invalid Input...\n\t Please enter only integers             :"
            );
        } while (!premierLeagueManager.checkClubExists(teamTwoRegNumber));
        matchDate = consoleValidation.getDateInput("Enter modified date                        : ",
                "Invalid date format ! [DD/MM/YYYY]     ");
//        playedDate = consoleValidation.getDateInput("Enter played date                        : ",
//                "Invalid date format ! [DD/MM/YYYY]     ");
        teamOneScore = consoleValidation.getIntegerInput("\t (*) Enter Team one scored goals                 :",
                "(!!) Invalid Input...\n\t Please enter only integers             :");
        teamTwoScore = consoleValidation.getIntegerInput("\t (*) Enter Team two scored goals                 :",
                "(!!) Invalid Input...\n\t Please enter only integers             :");
        double teamOneReceived = teamTwoScore;
        double teamTwoReceived = teamOneScore;
        footballClub.setMatchDate(matchDate);
        premierLeagueManager.updateStatistic(teamOneRegNumber, teamTwoRegNumber, teamOneScore, teamTwoScore, teamOneReceived, teamTwoReceived, matchDate);
    }
}



