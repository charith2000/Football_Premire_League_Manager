import entities.FootballClub;
import entities.SportsClub;

public interface LeagueManager {
    boolean checkClubExists(Integer regNumber);

    void addNewClub(SportsClub sportsClub);

    void deleteMember(Integer regNumber);

    void deleteMember(String name);

    void displayStatisticOfSelectedClub(Integer regNumber);

    void addStatistic(Integer registrationNumber, FootballClub footballClub);

    void sortPremierLeagueTable();

    void updateStatistic(Integer regNumberOne, Integer regNumberTwo, double teamOneScore, double teamTwoScore, double scoreOneReceived, double scoreTwoReceived, String matchDate);
}
